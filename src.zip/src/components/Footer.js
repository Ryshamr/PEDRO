import React from "react";
import "../styles/Footer.css";

function Footer() {
  return (
    <div className="footer">
      <div className="socialMedia">
        <span>Instagram</span> <span>Twitter</span> <span>Facebook</span> <span>LinkedIn</span>
      </div>
      <p> &copy; 2023 cred.com</p>
    </div>
  );
}

export default Footer;
